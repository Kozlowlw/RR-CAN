from can.interfaces.neovi_api.neovi_api import NeoVIBus
